import { Component, OnInit } from '@angular/core';



@Component({
	selector: 'form',
	templateUrl: 'form.component.html'
})

export class FormComponent implements OnInit {

	ngOnInit() { }
}
