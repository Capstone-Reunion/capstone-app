export interface Card{
    id?:string;
    username:string;
    email:string;
    password: string;
    appname: string;
    comments: string;
    piro:number;

}
